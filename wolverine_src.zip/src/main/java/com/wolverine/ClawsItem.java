package com.wolverine;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class ClawsItem extends Item {
    public ClawsItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.SUCCESS;
        }
        if (sp.isShiftKeyDown()) {
            Powers.olfato(sp);
            sp.getCooldowns().addCooldown(sp.getItemInHand(hand), Powers.OLFATO_COOLDOWN_TICKS);
        } else {
            Powers.furia(sp);
            sp.getCooldowns().addCooldown(sp.getItemInHand(hand), Powers.FURIA_COOLDOWN_TICKS);
        }
        return InteractionResult.SUCCESS;
    }
}
