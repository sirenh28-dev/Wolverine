package com.wolverine;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

public final class Powers {
    public static final int FURIA_COOLDOWN_TICKS = 60 * 20;
    public static final int OLFATO_COOLDOWN_TICKS = 20 * 20;
    private static final int FURIA_TICKS = 20 * 20;

    private Powers() {}

    /** Furia berserker: Velocidad II, Fuerza III y Resistencia II durante 20 s. */
    public static void furia(ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, FURIA_TICKS, 1, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.STRENGTH, FURIA_TICKS, 2, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, FURIA_TICKS, 1, false, false));
        ServerLevel level = (ServerLevel) p.level();
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.0f, 0.8f);
        level.sendParticles(ParticleTypes.ANGRY_VILLAGER, p.getX(), p.getY() + 1.8, p.getZ(), 8, 0.4, 0.3, 0.4, 0.0);
        Msg.overlay(p, "¡FURIA BERSERKER! (20 s)");
    }

    /** Sentidos agudizados: vision nocturna y brillo en los seres vivos a 32 bloques. */
    public static void olfato(ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 15 * 20, 0, false, false));
        ServerLevel level = (ServerLevel) p.level();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(32.0), x -> x != p)) {
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 10 * 20, 0, false, false));
        }
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_SNIFF, SoundSource.PLAYERS, 0.6f, 1.2f);
        Msg.overlay(p, "Sentidos agudizados");
    }

    /** Factor de curacion: con la chaqueta del traje puesta, regeneracion y limpieza de efectos malos. */
    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 20 != 0) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.CHAQUETA)) continue;
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1, false, false));
            p.removeEffect(MobEffects.POISON);
            p.removeEffect(MobEffects.WITHER);
            p.removeEffect(MobEffects.NAUSEA);
            p.removeEffect(MobEffects.WEAKNESS);
        }
    }
}
