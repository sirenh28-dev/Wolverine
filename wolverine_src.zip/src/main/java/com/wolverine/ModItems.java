package com.wolverine;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    /** Apunta a assets/wolverine/equipment/traje.json */
    public static final ResourceKey<EquipmentAsset> TRAJE_ASSET = ResourceKey.create(
            EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(WolverineMod.MOD_ID, "traje"));

    public static final ArmorMaterial TRAJE = new ArmorMaterial(
            10, defense(), 15, SoundEvents.ARMOR_EQUIP_LEATHER, 0.0F, 0.0F,
            ItemTags.REPAIRS_LEATHER_ARMOR, TRAJE_ASSET);

    public static Item GARRAS;
    public static Item MASCARA;
    public static Item CHAQUETA;
    public static Item PANTALONES;
    public static Item BOTAS;

    private ModItems() {}

    private static Map<ArmorType, Integer> defense() {
        Map<ArmorType, Integer> map = new EnumMap<>(ArmorType.class);
        map.put(ArmorType.HELMET, 1);
        map.put(ArmorType.CHESTPLATE, 3);
        map.put(ArmorType.LEGGINGS, 2);
        map.put(ArmorType.BOOTS, 1);
        map.put(ArmorType.BODY, 3);
        return map;
    }

    private static Identifier id(String name) {
        return Identifier.fromNamespaceAndPath(WolverineMod.MOD_ID, name);
    }

    private static Item armor(String name, ArmorType type) {
        Identifier id = id(name);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        return Registry.register(BuiltInRegistries.ITEM, id,
                new Item(new Item.Properties().setId(key).humanoidArmor(TRAJE, type)));
    }

    public static void register() {
        // Garras: 1 (base) + 7 = 8 de dano, velocidad de ataque 3.2. Sin durabilidad: irrompibles.
        Identifier id = id("garras");
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        ItemAttributeModifiers attrs = ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE,
                        new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, 7.0, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED,
                        new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -0.8, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .build();
        GARRAS = Registry.register(BuiltInRegistries.ITEM, id,
                new ClawsItem(new Item.Properties().setId(key).stacksTo(1).attributes(attrs)));

        MASCARA = armor("traje_mascara", ArmorType.HELMET);
        CHAQUETA = armor("traje_chaqueta", ArmorType.CHESTPLATE);
        PANTALONES = armor("traje_pantalones", ArmorType.LEGGINGS);
        BOTAS = armor("traje_botas", ArmorType.BOOTS);
    }
}
