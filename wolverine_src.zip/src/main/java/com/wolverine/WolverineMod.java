package com.wolverine;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.world.item.CreativeModeTabs;

/**
 * Wolverine:
 *  - Garras de adamantium (arma, 8 de dano): click derecho = furia berserker; agachado + click derecho = sentidos.
 *  - Traje (mascara, chaqueta, pantalones, botas): con la chaqueta puesta tienes factor de curacion.
 */
public class WolverineMod implements ModInitializer {
    public static final String MOD_ID = "wolverine";

    @Override
    public void onInitialize() {
        ModItems.register();

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(output -> {
            output.accept(ModItems.GARRAS);
            output.accept(ModItems.MASCARA);
            output.accept(ModItems.CHAQUETA);
            output.accept(ModItems.PANTALONES);
            output.accept(ModItems.BOTAS);
        });

        ServerTickEvents.END_SERVER_TICK.register(Powers::tick);
    }
}
